package VictorGopfert.Model;

public interface Reservavel {
    void realizarCheckin();
    void realizarCheckout();
}

